<?php

require_once 'include/DB_Functions.php';
$db = new DB_Functions();

$response = array("error" => FALSE);

if ( isset($_POST['email']) ) {

// receiving the post params
   
    $email = $_POST['email'];
    

    // check if user is already existed with the same email
    if (!$db->isUserExistedByEmail($email)) {
	   $response["error"] = TRUE;
	   $response["error_msg"] = "No user information with " . $email;
	   echo json_encode($response);

    } else {
	// send the email
	// $response["error"] = FALSE;
	   $token = uniqid();

	   if(!$db->setToken($email,$token)){
	       $response["error"] = TRUE;
	       $response["error_msg"] = "Permission deny";
	       echo json_encode($response);

	    } else{

	        $url = "128.206.20.147/Dashboard/admin/Info/change_pwd.php?email="."$email"."&&token="."$token";
            require_once('include/email.class.php');   
            //##########################################  
            $smtpserver = "smtp.126.com";//SMTP server 
            $smtpserverport = 25;//SMTP port
            $smtpusermail = "fosteringWellBeing@outlook.com";//who to send the email
            $smtpemailto = $email;//Receiver
      
            $smtpuser = "leiqing126@126.com";//user
            $smtppass = "47122081215";//password
            $mailsubject = "Test";//subject  
            $mailbody = "<p>Click the following link to set your new password or copy it and open in a browser.</p><p>".$url."</p>";//content
            $mailtype = "HTML";//format: HTML OR TEXT 
            ##########################################  
            $smtp = new smtp($smtpserver, $smtpserverport, true, $smtpuser, $smtppass);
            $smtp->debug = false;
            $state = $smtp->sendmail($smtpemailto, $smtpusermail, $mailsubject, $mailbody, $mailtype);

    	    if(!$state){
    	        $response["error"] = TRUE;
    	        $response["error_msg"] = "Email address can't be reached.";
    		    echo json_encode($response);

    	    } else{
        		$response["error"] = FALSE;
        		$response["user"]["email"] = $email;
        		$response["user"]["token"] = $token;
        		echo json_encode($response);
    	    }
        }

    }

} else {
    $response["error"] = TRUE;
    $response["error_msg"] = "Required parameters (email) is missing!";
    echo json_encode($response);
}

?>

