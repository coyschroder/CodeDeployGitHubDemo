<?php

/**
 * Database config variables
 */
define("DB_HOST", "128.206.20.147");
define("DB_USER", "ebw242");
define("DB_PASSWORD", "123456");
define("DB_DATABASE", "db_fostering");
?>
