<?php

/**
 * @author Qing Lei
 */

class DB_Functions {

    private $conn;

    // constructor
    function __construct() {
        require_once 'DB_Connect.php';
        // connecting to database
        $db = new Db_Connect();
        $this->conn = $db->connect();
    }

    // destructor
    function __destruct() {
        
    }

    /**
     * Storing new user's password
     * returns user details
     */
    public function storeUserPWD($id, $email, $password) {
 
        $password = md5($password); // encrypted password

	$stmt = $this->conn->prepare("SELECT * FROM userInfo WHERE password IS NOT NULL AND email = ? AND id = ?");

        $stmt->bind_param("ss", $email, $id);
        $result = $stmt->execute();
        $stmt->close();

        // check for valid user
        if ($result) {
	    $stmt = $this->conn->prepare("UPDATE userInfo SET password = ? WHERE email = ?");
            $stmt->bind_param("ss", $password, $email);
            $update = $stmt->execute();
	    // check for successful store
            if($update){
            	$stmt = $this->conn->prepare("SELECT * FROM userInfo WHERE password IS NOT NULL AND email = ?");
            	$stmt->bind_param("s", $email);
            	$stmt->execute();
            	$user = $stmt->get_result()->fetch_assoc();
            	$stmt->close();
            	return $user;
            }else{
		return NULL;
	    
	    }
        } else {
            return false;
        }
    }

    /**
     * Verify user login
     */
    public function VerifyLogin($email, $password) {

        $stmt = $this->conn->prepare("SELECT * FROM userInfo WHERE email = ?");

        $stmt->bind_param("s", $email);

        if ($stmt->execute()) {
            $user = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            // verifying user password
            $encrypted_password = $user['password'];
            $password = md5($password);
            // check for password equality
            if ($encrypted_password == $password) {
                // user authentication details are correct
                return $user;
            }
        } else {
            return NULL;
        }
    }

    /**
     * Check user is existed or not by email and id
     */
    public function isUserExisted($email, $id) {
        $stmt = $this->conn->prepare("SELECT * from userInfo WHERE password IS NOT NULL AND email = ? AND id = ?");

        $stmt->bind_param("ss", $email, $id);

        $stmt->execute();

        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            // user existed 
            $stmt->close();
            return true;
        } else {
            // user not existed
            $stmt->close();
            return false;
        }
    }

    /**
     * Check user is existed or not by email
     */
    public function isUserExistedByEmail($email) {
        $stmt = $this->conn->prepare("SELECT * from userInfo WHERE password IS NOT NULL AND email = ?");

        $stmt->bind_param("s", $email);

        $stmt->execute();

        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            // user existed 
            $stmt->close();
            return true;
        } else {
            // user not existed
            $stmt->close();
            return false;
        }
    }

    public function setToken($email,$token){
	$stmt = $this->conn->prepare("UPDATE userInfo SET token = ? WHERE email = ?");
        $stmt->bind_param("ss", $token, $email);
        $update = $stmt->execute();

	if($update) return true;
	else return false;

    }

}

?>
