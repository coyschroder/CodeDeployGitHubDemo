<!DOCTYPE html>
<html>
<head>
    <title></title>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="../Css/bootstrap.css" />
    <link rel="stylesheet" type="text/css" href="../Css/bootstrap-responsive.css" />
    <link rel="stylesheet" type="text/css" href="../Css/style.css" />
    <script type="text/javascript" src="..//Js/jquery.js"></script>
    <script type="text/javascript" src="../Js/jquery.sorted.js"></script>
    <script type="text/javascript" src="../Js/bootstrap.js"></script>
    <script type="text/javascript" src="../Js/ckform.js"></script>
    <script type="text/javascript" src="../Js/common.js"></script> 

    <style type="text/css">
        body {
            padding-bottom: 40px;
        }
        .sidebar-nav {
            padding: 9px 0;
        }
		.grey {
			color: #999;
		}
		.red {
			color: #F00;
		}
		.green {
			color: #0F0;
		}

        @media (max-width: 980px) {
            /* Enable use of floated navbar text */
            .navbar-text.pull-right {
                float: none;
                padding-left: 5px;
                padding-right: 5px;
            }
        }
    </style>
</head>
<body>
<form name="form1" action="set.php"  method="post" class="definewidth m20">
  <table class="table table-bordered table-hover ">
    <tr>
        <td width="10%" class="tableleft">Old password</td>
        <td ><input type="password" name="pass" style="float:left" onfocus="showTips(this)" onblur="checkInput(this)"/><div class="tips" style=" height:20px">&nbsp;</div></td>
    </tr>  
    <tr>
        <td class="tableleft">New password</td>
        <td><input type="password" name="pass1" style="float:left" onfocus="showTips(this)" onblur="checkInput(this)"/><div class="tips" style=" height:20px">&nbsp;</div></td>
    </tr>
    <tr>
        <td class="tableleft">Confirm password</td>
        <td><input type="password" name="pass2" style="float:left" onfocus="showTips(this)" onblur="checkInput(this)"/><div class="tips" style=" height:20px">&nbsp;</div></td>
    </tr>  
    <tr>
        <td class="tableleft">Operation</td>
        <td>
        <button name="submit"type="submit" class="btn btn-primary" value="save">Save</button>&nbsp;&nbsp;
             <button name="reset" type="button" onclick="ClearWhere()" class="btn btn-success" id="reset">Reset</button>
        </td>
    </tr>
</table>
</form>
</body>
</html>
<script>
var flag = [false, false];
var showTips = function(_obj){
tips = _obj.nextElementSibling;
			switch(_obj.name) {
				case "pass":
					tips.innerHTML = "Enter your old password";
					tips.className = "tips grey";
					break;
				case "pass1":
					tips.innerHTML = "At least 6 digits";
					tips.className = "tips grey";
					break;
				case "pass2":
					tips.innerHTML = "Comfirm";
					tips.className = "tips grey";
					break;
				default:
					break;
			}
		};
		var checkInput = function(_obj){
			var val = _obj.value;
			tips = _obj.nextElementSibling;
			switch(_obj.name) {
				case "pass1":
					if(RegExp("^\\w{6,}$").test(val)) {
						tips.innerHTML = "Valid password";
						tips.className = "tips green";
						flag[0] = true;
					} else {
						tips.innerHTML = "Invalid password";
						tips.className = "tips red";
						flag[0] = false;
					}
					break;
				case "password2":
				var pass1= (document.form1.pass1.value).replace(/(^\s*)|(\s*$)/g,"");
var pass2= (document.form1.pass2.value).replace(/(^\s*)|(\s*$)/g,"");

					if(flag[0]!=false&&pass1==pass2) {
						tips.innerHTML = "Valid Confirmed password";
						tips.className = "tips green";
						flag[1] = true;
					} else if(flag[0]!=false){
						tips.innerHTML = "Inalid Confirmed password";
						tips.className = "tips red";
						flag[1] = false;
					}
					break;
				
				default:
					break;
			}
		};

function ClearWhere() {
        $("#pass").val("");
        $("#pass1").val("");
        $("#pass2").val("");
    };
</script>
