<!DOCTYPE html>
<html>
<head>
    <title></title>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="../Css/bootstrap.css" />
    <link rel="stylesheet" type="text/css" href="../Css/bootstrap-responsive.css" />
    <link rel="stylesheet" type="text/css" href="../Css/style.css" />
    <script type="text/javascript" src="../Js/jquery.js"></script>
    <script type="text/javascript" src="../Js/jquery.sorted.js"></script>
    <script type="text/javascript" src="../Js/bootstrap.js"></script>
    <script type="text/javascript" src="../Js/ckform.js"></script>
    <script type="text/javascript" src="../Js/common.js"></script>

    <style type="text/css">
        body {
            padding-bottom: 40px;
			padding-top: 60px;
			padding-left: 40%;
			background-color: #CFCFCF;
			
        }
        .sidebar-nav {
            padding: 9px 0;
        }

        @media (max-width: 980px) {
            /* Enable use of floated navbar text */
            .navbar-text.pull-right {
                float: none;
                padding-left: 5px;
                padding-right: 5px;
            }
        }


    </style>
</head>
<body>
<div style="background-color:#fff;font-size:20px; color:#F00;text-align:center; vertical-align:central; width:300px; height:200px">
<br>
<br>
<?php
    include("../../conn.php");
	$id=$_COOKIE["myadmin"];
	$pass = $_POST["pass"];
	$pass1 = $_POST["pass1"];
	$pass2 = $_POST["pass2"];
	if($id==false){
	echo "<script language=javascript>alert('You have been logged out');location.href='../../index.php';</script>";}
	else {

	$sql=mysql_query("select password from adminInfo where id = '$id'",$conn) or die(mysql_error());
	$info=mysql_fetch_array($sql);
	$PSWD=$info[0];
	if($PSWD!=md5($pass))
	{
		echo "Your old password is not correct!";
	}
	else if($pass1!=$pass2)
	{
		echo "New password does not match!";
	}
	else{
	    $NEWPSWD=md5($pass1);
		$uppswd=mysql_query("update adminInfo set password = '$NEWPSWD' where id = '$id'",$conn) or die(mysql_error());	
    if($uppswd){    
	echo "Success!";
	echo "</br>";
	}
	//echo "Please use your new password to login next time!";}
	else{
	echo "Failed!";
	echo "</br>";
	echo "Please contact your technician.";}
	}
	}
	mysql_free_result($sql);
	mysql_close($conn);
?>
<br>
<br>
<br>
<br>

<button type="button" class="btn btn-success" name="backid" id="backid2">Back</button>
</div>

</body>
</html>
<script>
    $(function () {       
		$('#backid2').click(function(){
				window.location.href="change_pwd.php";
		 });

    });
</script>
