<!DOCTYPE html>
<html>
<head>
    <title></title>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="../Css/bootstrap.css" />
    <link rel="stylesheet" type="text/css" href="../Css/bootstrap-responsive.css" />
    <link rel="stylesheet" type="text/css" href="../Css/style.css" />
    <script type="text/javascript" src="../Js/jquery.js"></script>
    <script type="text/javascript" src="../Js/jquery.sorted.js"></script>
    <script type="text/javascript" src="../Js/bootstrap.js"></script>
    <script type="text/javascript" src="../Js/ckform.js"></script>
    <script type="text/javascript" src="../Js/common.js"></script>

    <style type="text/css">
        body {
            padding-bottom: 40px;
        }
        .sidebar-nav {
            padding: 9px 0;
        }

        @media (max-width: 980px) {
            /* Enable use of floated navbar text */
            .navbar-text.pull-right {
                float: none;
                padding-left: 5px;
                padding-right: 5px;
            }
        }


    </style>
</head>
<body>
<form class="form-inline definewidth m20" action="index_role.php" method="post">  
    ID:
    <input type="text" name="id" id="id" class="abc input-default">&nbsp;&nbsp;  
    <button type="submit" name="submit" value="Search" class="btn btn-primary">Search</button>
</form>
<table class="table table-bordered table-hover definewidth m10" >
    <thead>
    <tr>
        <th>id</th>  
        <th>Last login time</th>
        <th>Operation</th>
    </tr>
    </thead>
	<?php 
	include("../../conn.php");
	$id=$_COOKIE["myadmin"];
	$sql="select id,lastLoginDateTime from adminInfo where id = '$id'";
	$result=mysql_query($sql,$conn);
	$info=mysql_fetch_array($result);
	?>
	<tr>
	<td><?php echo $info[0]; ?></td>
	<td><?php echo $info[1]; ?></td>
	<td>
	<?php	
		echo "<a href='change_pwd.php?id=".$info[0]."'>Change your password</a>"; 
	?>
	
	</td>
	</tr>
        </table>
	</body>
</html>

