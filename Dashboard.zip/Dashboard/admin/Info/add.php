<!DOCTYPE html>
<html>
<head>
    <title></title>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="../Css/bootstrap.css" />
    <link rel="stylesheet" type="text/css" href="../Css/bootstrap-responsive.css" />
    <link rel="stylesheet" type="text/css" href="../Css/style.css" />
    <script type="text/javascript" src="../Js/jquery.js"></script>
    <script type="text/javascript" src="../Js/jquery.sorted.js"></script>
    <script type="text/javascript" src="../Js/bootstrap.js"></script>
    <script type="text/javascript" src="../Js/ckform.js"></script>
    <script type="text/javascript" src="../Js/common.js"></script>

    <style type="text/css">
        body {
            padding-bottom: 40px;
			padding-top: 60px;
			padding-left: 40%;
			background-color: #CFCFCF;
			
        }
        .sidebar-nav {
            padding: 9px 0;
        }

        @media (max-width: 980px) {
            /* Enable use of floated navbar text */
            .navbar-text.pull-right {
                float: none;
                padding-left: 5px;
                padding-right: 5px;
            }
        }
    </style>
</head>   
<body>
<div style="background-color:#fff;font-size:20px; color:#F00;text-align:center; vertical-align:central; width:300px; height:200px">
<br>
<br>
<?php
	$email=$_POST['email'];
	$type=$_POST['type'];
	$id = $_POST['id'];
	include("../../conn.php");
	$sql=mysql_query("select email from userInfo where email ='$email' or id = '$id'",$conn) or die(mysql_error());
	$info=mysql_fetch_array($sql);
	if($info[0]!=NULL){
    	echo "Error!";
    	echo "<br>";
    	echo "Email/ID already exist!";
    }else{
	    
        require_once('email.class.php');  
        //##########################################  

        $smtpserver = "smtp.126.com";//SMTP server 
        $smtpserverport = 25;//SMTP port
        $smtpusermail = "leiqing126@126.com";//who to send the email
        $smtpemailto = $email;//Receiver
      
        $smtpuser = "leiqing126";//user
        $smtppass = "47122081215";//password
        $mailsubject = "Test";//subject  
        $mailbody = "<h1> Registration code for fostering well-being</h1><p>".$id."</p>";//content
        $mailtype = "HTML";//format: HTML OR TEXT 
        ##########################################  
        $smtp = new smtp($smtpserver, $smtpserverport, true, $smtpuser, $smtppass);
        $smtp->debug = true;
        $state = $smtp->sendmail($smtpemailto, $smtpusermail, $mailsubject, $mailbody, $mailtype); 

        if($state != ""){
                //echo "Email has been sent!";
                $ins = "insert into userInfo(email,id,type) values('$email','$id','$type')";
                $i = mysql_query($ins,$conn) or die(mysql_error());
     
                if($i!=false){
                    echo "Success!"; 
                }

                else{
                    echo "Error!";
                }
                
        }
        else echo "Invalid email address.";
        
    }
	mysql_free_result($sql);
	mysql_close($conn);
?>
<br>
<br>
<br>
<br>
<br>
<button type="button" class="btn btn-success" name="backid" id="backid"> Back</button>
</div>

</body>
</html>
<script>

    $(function () {       
		$('#backid').click(function(){
				window.location.href="add_user.php";
		 });

    });
</script>
