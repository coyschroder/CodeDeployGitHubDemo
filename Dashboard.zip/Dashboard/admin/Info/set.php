<!DOCTYPE html>
<html>
<head>
    <title></title>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="../Css/bootstrap.css" />
    <link rel="stylesheet" type="text/css" href="../Css/bootstrap-responsive.css" />
    <link rel="stylesheet" type="text/css" href="../Css/style.css" />
    <script type="text/javascript" src="../Js/jquery.js"></script>
    <script type="text/javascript" src="../Js/jquery.sorted.js"></script>
    <script type="text/javascript" src="../Js/bootstrap.js"></script>
    <script type="text/javascript" src="../Js/ckform.js"></script>
    <script type="text/javascript" src="../Js/common.js"></script>

    <style type="text/css">
        body {
            padding-bottom: 40px;
			padding-top: 60px;
			padding-left: 40%;
			background-color: #CFCFCF;
			
        }
        .sidebar-nav {
            padding: 9px 0;
        }

        @media (max-width: 980px) {
            /* Enable use of floated navbar text */
            .navbar-text.pull-right {
                float: none;
                padding-left: 5px;
                padding-right: 5px;
            }
        }


    </style>
</head>
<body>
<div style="background-color:#fff;font-size:20px; color:#F00;text-align:center; vertical-align:central; width:300px; height:200px">
<br>
<br>
<?php
    include("../../conn.php");
	$email = $_GET["email"];
	$pass1 = $_POST["pass1"];	
	$NEWPSWD=md5($pass1);
	$uppswd=mysql_query("update userInfo set password = '$NEWPSWD', token = null where email = '$email'",$conn) or die(mysql_error());	
    if($uppswd){    
	   echo "Success!";
	   echo "</br>";

	}
	else{
	   echo "Failed!";
	   echo "</br>";
	   echo "Please contact your technician.";
	}
	
	mysql_close($conn);
?>
<br>
<br>
<br>
<br>


</body>
</html>

