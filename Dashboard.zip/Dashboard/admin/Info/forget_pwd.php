<?php
	include('../../conn.php');
	$email=$_GET['email'];
	$token = uniqid();

	$info = mysql_query("update userInfo set token = '$token' where email ='$email'",$conn);
	if($info == false){
    	echo "Email address does not exist! Please try again.";
   
    	}else{
	
	    $url = "128.206.20.147/Dashboard/admin/Info/change_pwd.php?email="."$email"."&&token="."$token";
        require_once('email.class.php');   
        //##########################################  
        $smtpserver = "smtp.126.com";//SMTP server 
        $smtpserverport = 25;//SMTP port
        $smtpusermail = "leiqing126@126.com";//who to send the email
        $smtpemailto = $email;//Receiver
        //$smtpemailto = "38161943@qq.com";// to whom  
        $smtpuser = "leiqing126@126.com";//user
        $smtppass = "47122081215";//password
        $mailsubject = "Test";//subject  
        $mailbody = "<p>Please click or copy the following link to change your password</p><p>".$url."</p>";//content
        $mailtype = "HTML";//format: HTML OR TEXT 
        ##########################################  
        $smtp = new smtp($smtpserver, $smtpserverport, true, $smtpuser, $smtppass);
        $smtp->debug = false;
        $state=$smtp->sendmail($smtpemailto, $smtpusermail, $mailsubject, $mailbody, $mailtype); 

        if($state!=""){
            echo "Email has been sent!";    
        }
        else echo "Invalid email address.";
        
    }
?>

