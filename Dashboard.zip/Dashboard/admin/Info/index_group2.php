﻿<!DOCTYPE html>
<html>
<head>
    <title></title>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="../Css/bootstrap.css" />
    <link rel="stylesheet" type="text/css" href="../Css/bootstrap-responsive.css" />
    <link rel="stylesheet" type="text/css" href="../Css/style.css" />
    <link rel="stylesheet" type="text/css" href="../Css/bootstrap-select.css" />
    <script type="text/javascript" src="../Js/jquery.js"></script>
    <script type="text/javascript" src="../Js/bootstrap.js"></script>
    <script type="text/javascript" src="../Js/ckform.js"></script>
    <script type="text/javascript" src="../Js/common.js"></script>
    <script type="text/javascript" src="../Js/bootstrap-select.js"></script>

    <style type="text/css">
        body {
            padding-bottom: 40px;
        }
        .sidebar-nav {
            padding: 9px 0;
        }

        @media (max-width: 980px) {
            /* Enable use of floated navbar text */
            .navbar-text.pull-right {
                float: none;
                padding-left: 5px;
                padding-right: 5px;
            }
        }


    </style>
    <script type="text/javascript">
      window.onload=function(){
      $('.selectpicker').selectpicker();
      };
    </script>
</head>
<body>
<form class="form-inline definewidth m20" action="index_group2.php" method="post">  
    Email：
    <input type="text" name="email" id="email" class="abc input-default">&nbsp;&nbsp;
    <button name="submit" type="submit" class="btn btn-primary" value="Search">Search</button>

    
</form>
<?php
        include("../../conn.php");
        $pageSize = 10;     //total records
        $rowCount = 0;  //from database      
        $sqlCount = "select count(*) from userInfo where type = 1";

        $res1 = mysql_query($sqlCount,$conn);

        //get row count
        if(false!=($row=mysql_fetch_row($res1))){
            $rowCount = $row[0];
            //echo $rowCount; 
        }        
        //calculate page count
        $pageCount = 0;
        $pageCount = ceil($rowCount/$pageSize);         
        //get current page
        if(!isset($_GET['pageNow'])){           
		// default 1
         $pageNow = 1;   //current
        }
		elseif(false!=is_numeric($_GET['pageNow']) && $_GET['pageNow']<=$pageCount){
            $pageNow = $_GET['pageNow'];
        }
		else{
            exit();
        } 
?>
<table class="table table-bordered table-hover definewidth m10" >
    <thead>
    <tr>
        <th>Email</th>
        <th>ID</th>
        <th>Operation</th>
    </tr>
    </thead>
     <?php 	
     if (isset($_POST['submit'])=="Search"){
		$S_email=$_POST['email'];
        $sql="select email,id from userInfo where type = 1 ";
        if($S_email!="")
        $sql.="and userInfo.email = '$S_email'";
        //echo $sql;
        $result=mysql_query($sql,$conn) or die(mysql_error());
        $info=mysql_fetch_array($result);
        if($info==false){          //not exist
            echo "<div align='center' style='color:#FF0000; font-size:12px'>No Record!</div>";
        }
        else{ 
            do{ ?>
                 <tr>
                    <td><?php echo $info[0]; ?></td>
                    <td><?php echo $info[1]; ?></td>
                    <td>
                    <?php
                    //include("../../conn.php");
                    
                        echo "<a href='delete2.php?email=".$info[0]."'>Delete</a>";
                   
                    ?>
                    </td>
                </tr>
            <?php 
            }
            while( $info=mysql_fetch_array($result));
        }
	}

	else {
		$sql="select email,id from userInfo where type = 1 limit ".($pageNow-1)*$pageSize.",".$pageSize."";
        //$sql="select email,id from userInfo where type = 0";
		$result=mysql_query($sql,$conn);
        while($info=mysql_fetch_array($result)){?>


         <tr>
            <td><?php echo $info[0];?></td>
            <td><?php echo $info[1];?></td>
            <td><?php
                    //include("../../conn.php");
               
                        echo "<a href='delete2.php?email=".$info[0]."'>Delete</a>";
                   
                    ?></td>
         </tr>
         <?php } 

        

	echo "</table>";
	
	
        //form
            echo "<form class='form-inline definewidth m20' action='index_group1.php?pageNow='".$pageNow."'' method='get'>";
			echo "<div class='inline pull-right page' style='font-size:12px'>";
			if(!isset($_GET['pageNow'])){           //default 1
            $pageNow = 1;   //current page
        }elseif(false!=is_numeric($_GET['pageNow']) && $_GET['pageNow']<=$pageCount){
            $pageNow = $_GET['pageNow'];
        }else{
            exit();
        }
        if($pageCount<=1){
			echo "Total ".$rowCount." record(s)";
		}
		else{
			echo "At most ".$pageSize." per page/".$rowCount." record(s)&nbsp;&nbsp;";
		    if($pageNow!=1){
			echo "<a href='?pageNow=1'>1</a>&nbsp;";}
            //prev
            if($pageNow>1){    
                $pageUp = $pageNow-1;
                echo "<a href='?pageNow=".$pageUp."'>prev&nbsp;</a>";
            }
			else{echo "prev&nbsp;&nbsp;";}
             
            //next
            if($pageNow < $pageCount){
                $pageDown = $pageNow+1;
                echo "<a href='?pageNow=".$pageDown."'>next&nbsp;</a>";
            }
			else {echo "next&nbsp;&nbsp;";} 
		    if($pageNow!=$pageCount){
			echo "<a href='?pageNow=".$pageCount."'>last</a>&nbsp;";}
             
            echo "<br/>".$pageNow."/".$pageCount."";                      
            //go to
            echo "&nbsp;go to：<select name='pageNow' class='selectpicker'>";
			for($j=1; $j<=$pageCount; $j++){
			echo "<option>$j</option>";}
			echo "</select>&nbsp";
			echo "<button name='go' type='submit' class='btn btn-success' value='go'>submit</button>";
			}
			echo "</div>";
            echo "</form>";
	}
?>

</body>
</html> 
