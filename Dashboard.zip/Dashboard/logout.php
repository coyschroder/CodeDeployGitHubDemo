<?php
   setcookie('mycookie',time()-3600);
   header("Location:index.php");//
?>
