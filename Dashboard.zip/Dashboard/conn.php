<?php

	$conn = mysql_connect("128.206.20.147","ebw242","123456");
	mysql_select_db("db_fostering",$conn);  

?>
